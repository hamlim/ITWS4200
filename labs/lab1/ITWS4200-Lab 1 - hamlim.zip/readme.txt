The key step i took to make this lab easier was to edit the JSON file to make it a javascript file and make
the data all be stored in an array that i could read in easier without any special techniques from jquery.

I am also using the Foundation 5 css layout for the clean looking and easy to use grid layout. 

The project seemed fairly simple, recieved help from several people in class on their different
methods for solving the lab. 

Ultimately, i went for simplicity over functionality, no unnecessary text anywhere, or boxes or ads 
just the tweets.