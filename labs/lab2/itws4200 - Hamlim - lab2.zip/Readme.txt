A majority of the code takes place in the javascript
file, I would say that about 80% of the code is in js
10% in css and another 10% in the html itself. As the
same in lab 1 I went for simplicity, it is a little bit
more creatively designed than lab 1, given that I gave 
more focus to the layout of the content on the website.

I used Foundation 5 for the header and footer styling
and that was about it. I used a custom designed "Google -
Now" themed "card" style for the actual weather 
information. This provides the weather in a easy to read
and pleasent form factor.


I used a set of svg's offered for free download by
Adam Whitcroft (http://adamwhitcroft.com/climacons) link 
to download the icons in the parentheses. 

The hardest work was not actually in implementing the 
Forecast.io api but rather the HTML5 Geolocation api to 
be able to use the latitude and longitude values. I ended
up using a huge mess of nested functions loops and 
statements to make it work. 