Over all the lab was pretty simple, although File system on Nodejs was a bit of a pain given that I did not properly read that fs.writefile() 
would overwrite the contents in a file, so I ended up looking at my file and only finding one json object for a tweet not the expected amounts
I was hoping for. 

Other than that i spent more time making the file of tweets itself and transfering it over to a zip folder because of the amount of content we 
had to find through the twitter api.

I used nTwitter to get all the content, it isn't that bad, but I am surprised that the count parameter does not exist for nTwitter.